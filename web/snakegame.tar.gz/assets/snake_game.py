import pygame
import random
import sys

# ==================== 初始化 ====================
pygame.init()

# 窗口设置
CELL_SIZE = 25
COLS = 30
ROWS = 22
WIDTH = COLS * CELL_SIZE
HEIGHT = ROWS * CELL_SIZE + 60  # 顶部留出分数栏

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("🐍 贪吃蛇大作战")
clock = pygame.time.Clock()

# 颜色
BG_COLOR = (30, 30, 40)
GRID_COLOR = (40, 40, 55)
SNAKE_HEAD_COLOR = (100, 220, 100)
SNAKE_BODY_COLOR = (60, 180, 60)
SNAKE_BODY_ALT_COLOR = (50, 160, 50)
FOOD_COLOR = (255, 80, 80)
FOOD_GLOW_COLOR = (255, 150, 150)
TEXT_COLOR = (220, 220, 220)
SCORE_BG = (20, 20, 30)
OVERLAY_COLOR = (0, 0, 0, 180)

# 字体 - 使用系统中文字体避免乱码
def get_chinese_font(size):
    """获取支持中文的系统字体，优先微软雅黑"""
    font_names = ["Microsoft YaHei", "SimHei", "SimSun", "KaiTi", "FangSong", "Arial"]
    for name in font_names:
        try:
            return pygame.font.SysFont(name, size)
        except:
            continue
    return pygame.font.Font(None, size)

font_score = get_chinese_font(40)
font_title = get_chinese_font(72)
font_sub = get_chinese_font(32)
font_small = get_chinese_font(24)

# 方向向量
DIRECTIONS = {
    pygame.K_UP: (0, -1),
    pygame.K_DOWN: (0, 1),
    pygame.K_LEFT: (-1, 0),
    pygame.K_RIGHT: (1, 0),
}


class Snake:
    def __init__(self):
        self.reset()

    def reset(self):
        cx, cy = COLS // 2, ROWS // 2
        self.body = [(cx, cy), (cx - 1, cy), (cx - 2, cy)]
        self.direction = (1, 0)  # 初始向右
        self.growing = False
        self.alive = True

    def move(self):
        if not self.alive:
            return
        head = self.body[0]
        new_head = (head[0] + self.direction[0], head[1] + self.direction[1])
        self.body.insert(0, new_head)
        if not self.growing:
            self.body.pop()
        else:
            self.growing = False

    def grow(self):
        self.growing = True

    def set_direction(self, dx, dy):
        # 不允许反向
        if (dx, dy) == (-self.direction[0], -self.direction[1]):
            return
        self.direction = (dx, dy)

    def head(self):
        return self.body[0]


class Food:
    def __init__(self):
        self.position = (0, 0)
        self.pulse = 0

    def spawn(self, snake_body):
        while True:
            pos = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
            if pos not in snake_body:
                self.position = pos
                break

    def update_animation(self):
        self.pulse = (self.pulse + 0.08) % (2 * 3.14159)


def draw_grid(surface):
    for x in range(0, WIDTH, CELL_SIZE):
        pygame.draw.line(surface, GRID_COLOR, (x, 60), (x, HEIGHT))
    for y in range(60, HEIGHT, CELL_SIZE):
        pygame.draw.line(surface, GRID_COLOR, (0, y), (WIDTH, y))


def draw_snake(surface, snake):
    body = snake.body
    head = body[0]
    for i, (bx, by) in enumerate(body):
        rx = bx * CELL_SIZE
        ry = by * CELL_SIZE + 60
        rect = pygame.Rect(rx + 1, ry + 1, CELL_SIZE - 2, CELL_SIZE - 2)

        if i == 0:
            # 蛇头
            color = SNAKE_HEAD_COLOR
            pygame.draw.rect(surface, color, rect, border_radius=8)
            # 眼睛
            eye_r = 4
            dx, dy = snake.direction
            cx = rx + CELL_SIZE // 2
            cy_ = ry + CELL_SIZE // 2
            if dx == 1:  # 向右
                e1 = (cx + 5, cy_ - 5)
                e2 = (cx + 5, cy_ + 5)
            elif dx == -1:  # 向左
                e1 = (cx - 5, cy_ - 5)
                e2 = (cx - 5, cy_ + 5)
            elif dy == -1:  # 向上
                e1 = (cx - 5, cy_ - 5)
                e2 = (cx + 5, cy_ - 5)
            else:  # 向下
                e1 = (cx - 5, cy_ + 5)
                e2 = (cx + 5, cy_ + 5)
            pygame.draw.circle(surface, (255, 255, 255), e1, eye_r)
            pygame.draw.circle(surface, (255, 255, 255), e2, eye_r)
            pygame.draw.circle(surface, (0, 0, 0), e1, eye_r // 2)
            pygame.draw.circle(surface, (0, 0, 0), e2, eye_r // 2)
        else:
            # 蛇身（交替颜色）
            color = SNAKE_BODY_COLOR if i % 2 == 0 else SNAKE_BODY_ALT_COLOR
            pygame.draw.rect(surface, color, rect, border_radius=6)


def draw_food(surface, food):
    fx, fy = food.position
    cx = fx * CELL_SIZE + CELL_SIZE // 2
    cy_ = fy * CELL_SIZE + CELL_SIZE // 2 + 60
    r = int(CELL_SIZE // 2 - 2 + 2 * pygame.math.Vector2(0, 1).rotate_rad(food.pulse).y)

    # 光晕
    pygame.draw.circle(surface, FOOD_GLOW_COLOR, (cx, cy_), r + 3)
    # 食物本体
    pygame.draw.circle(surface, FOOD_COLOR, (cx, cy_), r)
    # 高光
    pygame.draw.circle(surface, (255, 180, 180), (cx - 3, cy_ - 3), r // 3)


def check_collision(snake):
    head = snake.head()
    hx, hy = head
    # 撞墙
    if hx < 0 or hx >= COLS or hy < 0 or hy >= ROWS:
        return True
    # 撞自己
    if head in snake.body[1:]:
        return True
    return False


def draw_score_bar(surface, score, high_score):
    pygame.draw.rect(surface, SCORE_BG, (0, 0, WIDTH, 60))

    score_text = font_score.render(f"🍎 得分: {score}", True, TEXT_COLOR)
    high_text = font_score.render(f"🏆 最高: {high_score}", True, (255, 215, 0))
    hint_text = font_small.render("↑↓←→ 移动  |  R 重新开始  |  ESC 退出", True, (150, 150, 150))

    surface.blit(score_text, (20, 12))
    surface.blit(high_text, (WIDTH // 2 - high_text.get_width() // 2, 12))
    surface.blit(hint_text, (WIDTH - hint_text.get_width() - 15, 38))


def draw_game_over(surface, score, high_score):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 170))
    surface.blit(overlay, (0, 0))

    title = font_title.render("游戏结束", True, (255, 100, 100))
    score_line = font_sub.render(f"得分: {score}", True, TEXT_COLOR)
    high_line = font_sub.render(f"最高分: {high_score}", True, (255, 215, 0))
    restart_line = font_small.render("按 R 键重新开始  |  按 ESC 键退出", True, (180, 180, 180))

    cx = WIDTH // 2
    cy = HEIGHT // 2
    surface.blit(title, (cx - title.get_width() // 2, cy - 100))
    surface.blit(score_line, (cx - score_line.get_width() // 2, cy - 20))
    surface.blit(high_line, (cx - high_line.get_width() // 2, cy + 30))
    surface.blit(restart_line, (cx - restart_line.get_width() // 2, cy + 85))


def main():
    snake = Snake()
    food = Food()
    food.spawn(snake.body)
    score = 0
    high_score = 0
    game_over = False
    move_timer = 0
    MOVE_DELAY = 100  # 毫秒

    running = True
    while running:
        dt = clock.tick(60)  # 60 FPS

        # ==================== 事件处理 ====================
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if not snake.alive:
                    if event.key == pygame.K_r:
                        snake.reset()
                        food.spawn(snake.body)
                        score = 0
                        game_over = False
                        move_timer = 0
                    elif event.key == pygame.K_ESCAPE:
                        running = False

                if event.key in DIRECTIONS:
                    snake.set_direction(*DIRECTIONS[event.key])

        # ==================== 游戏逻辑 ====================
        if snake.alive:
            move_timer += dt
            if move_timer >= MOVE_DELAY:
                move_timer -= MOVE_DELAY
                snake.move()

                # 吃食物
                if snake.head() == food.position:
                    snake.grow()
                    score += 10
                    food.spawn(snake.body)
                    # 加速
                    MOVE_DELAY = max(50, MOVE_DELAY - 1)

                # 碰撞检测
                if check_collision(snake):
                    snake.alive = False
                    game_over = True
                    if score > high_score:
                        high_score = score

        # ==================== 渲染 ====================
        screen.fill(BG_COLOR)
        draw_grid(screen)
        draw_food(screen, food)
        draw_snake(screen, snake)
        draw_score_bar(screen, score, high_score)

        if game_over:
            draw_game_over(screen, score, high_score)

        # 食物动画
        food.update_animation()

        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()

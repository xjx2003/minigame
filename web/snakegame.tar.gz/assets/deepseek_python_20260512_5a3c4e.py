import pygame
import random
import sys

# 初始化 Pygame
pygame.init()

# 游戏设置
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 600
GRID_SIZE = 20          # 网格大小，蛇和食物都按格子移动
GRID_WIDTH = WINDOW_WIDTH // GRID_SIZE
GRID_HEIGHT = WINDOW_HEIGHT // GRID_SIZE
FPS = 10                # 初始移动速度

# 颜色
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
GRAY = (50, 50, 50)
YELLOW = (255, 255, 0)

# 方向向量
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)


class Snake:
    def __init__(self):
        # 蛇身由多个格子坐标组成，[0] 是蛇头
        self.body = [(GRID_WIDTH // 2, GRID_HEIGHT // 2)]
        self.direction = RIGHT
        self.grow = False

    def move(self):
        """移动蛇，返回是否撞到自己"""
        head = self.body[0]
        new_head = (head[0] + self.direction[0], head[1] + self.direction[1])

        # 穿墙处理：走出边界就从另一边出现
        new_head = (new_head[0] % GRID_WIDTH, new_head[1] % GRID_HEIGHT)

        # 撞到自己
        if new_head in self.body:
            return False

        self.body.insert(0, new_head)
        if not self.grow:
            self.body.pop()
        else:
            self.grow = False
        return True

    def change_direction(self, new_dir):
        """禁止原地掉头"""
        if (new_dir[0] * -1, new_dir[1] * -1) != self.direction:
            self.direction = new_dir

    def eat_food(self):
        self.grow = True


class Food:
    def __init__(self, snake):
        self.position = self.randomize_position(snake)

    def randomize_position(self, snake):
        """在空位上随机生成食物"""
        while True:
            pos = (random.randint(0, GRID_WIDTH - 1),
                   random.randint(0, GRID_HEIGHT - 1))
            if pos not in snake.body:
                return pos


def draw_grid(screen):
    """绘制网格线（可选，让画面更直观）"""
    for x in range(0, WINDOW_WIDTH, GRID_SIZE):
        pygame.draw.line(screen, GRAY, (x, 0), (x, WINDOW_HEIGHT))
    for y in range(0, WINDOW_HEIGHT, GRID_SIZE):
        pygame.draw.line(screen, GRAY, (0, y), (WINDOW_WIDTH, y))


def draw_objects(screen, snake, food):
    """绘制蛇和食物"""
    # 画蛇身
    for i, pos in enumerate(snake.body):
        rect = pygame.Rect(pos[0] * GRID_SIZE, pos[1] * GRID_SIZE,
                           GRID_SIZE, GRID_SIZE)
        color = YELLOW if i == 0 else GREEN   # 蛇头用不同颜色
        pygame.draw.rect(screen, color, rect)

    # 画食物
    food_rect = pygame.Rect(food.position[0] * GRID_SIZE,
                            food.position[1] * GRID_SIZE,
                            GRID_SIZE, GRID_SIZE)
    pygame.draw.rect(screen, RED, food_rect)


def show_game_over(screen, score):
    """显示游戏结束界面"""
    font = pygame.font.Font(None, 50)
    text1 = font.render("Game Over!", True, RED)
    text2 = font.render(f"Score: {score}", True, WHITE)
    text3 = font.render("Press R to restart or Q to quit", True, WHITE)

    screen.blit(text1, (WINDOW_WIDTH//2 - text1.get_width()//2, 200))
    screen.blit(text2, (WINDOW_WIDTH//2 - text2.get_width()//2, 260))
    screen.blit(text3, (WINDOW_WIDTH//2 - text3.get_width()//2, 320))
    pygame.display.update()


def show_score(screen, score):
    """显示当前分数"""
    font = pygame.font.Font(None, 30)
    text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(text, (10, 10))


def main():
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("贪吃蛇")
    clock = pygame.time.Clock()

    snake = Snake()
    food = Food(snake)
    score = 0
    running = True
    game_over = False

    while running:
        # 处理事件
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if game_over:
                    if event.key == pygame.K_r:
                        # 重启游戏
                        snake = Snake()
                        food = Food(snake)
                        score = 0
                        game_over = False
                    elif event.key == pygame.K_q:
                        running = False
                else:
                    # 游戏中方向控制（兼容 WASD 和方向键）
                    if event.key == pygame.K_UP or event.key == pygame.K_w:
                        snake.change_direction(UP)
                    elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                        snake.change_direction(DOWN)
                    elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                        snake.change_direction(LEFT)
                    elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                        snake.change_direction(RIGHT)

        if not game_over:
            # 移动蛇
            alive = snake.move()
            if not alive:
                game_over = True
                continue

            # 检测吃食物
            if snake.body[0] == food.position:
                snake.eat_food()
                score += 1
                # 每吃5个食物加速一次（上限15）
                if score % 5 == 0:
                    global FPS
                    FPS = min(FPS + 1, 15)
                food = Food(snake)

            # 绘制
            screen.fill(BLACK)
            draw_grid(screen)
            draw_objects(screen, snake, food)
            show_score(screen, score)
        else:
            # 绘制结束画面
            screen.fill(BLACK)
            show_game_over(screen, score)

        pygame.display.update()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
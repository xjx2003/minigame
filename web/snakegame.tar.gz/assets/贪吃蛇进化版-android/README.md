# 🐍 贪吃蛇进化版 — Android

基于 Python + Kivy 框架开发的贪吃蛇游戏，支持多种食物类型、难度选择和粒子特效。

## 项目结构

```
贪吃蛇进化版-android/
├── main.py              # 入口文件（Kivy App）
├── buildozer.spec       # APK 打包配置
├── requirements.txt     # Python 依赖
├── README.md            # 本文件
├── game/
│   ├── __init__.py
│   ├── core.py          # 游戏核心逻辑（纯 Python，无 UI）
│   ├── screens.py       # Kivy 游戏界面与渲染
│   └── sounds.py        # 音效管理与生成
└── sounds/              # 运行时自动生成的 WAV 音效文件
```

## 本地运行测试

```bash
# 1. 安装 Kivy
pip install kivy

# 2. 运行游戏
python main.py
```

> 注意：在 Windows/macOS/Linux 上运行时会显示一个 480×800 的窗口，
> 键盘方向键 / WASD 也可控制方向。

## 打包为 Android APK

### 方法一：使用 Google Colab（推荐，无需本地 Linux）

1. 打开在线 Colab 笔记本：
   https://colab.research.google.com/github/kivy/kivy/blob/master/examples/misc/buildozer_colab.ipynb

2. 在 Colab 中运行以下命令（每次一个单元格）：

```bash
# 安装 Buildozer 及其依赖
!pip install buildozer
!sudo apt update
!sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev

# 上传项目文件
# 在 Colab 左侧文件面板中上传整个项目文件夹

# 或从 GitHub 克隆（如果你已推送到 GitHub）
# !git clone https://github.com/你的用户名/贪吃蛇进化版-android.git
# %cd 贪吃蛇进化版-android

# 构建 APK（首次构建约需 20-30 分钟）
!buildozer android debug
```

3. 构建完成后，APK 文件位于 `bin/` 目录下，名为 `snakeevolution-1.0.0-debug.apk`

4. 下载 APK 并发送到手机安装即可。

### 方法二：使用 GitHub Actions（自动构建）

1. 将项目推送到 GitHub 仓库
2. 在仓库中创建 `.github/workflows/build.yml`：

```yaml
name: Build Android APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - name: Install dependencies
        run: |
          pip install buildozer
          sudo apt update
          sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
      - name: Build APK
        run: |
          buildozer android debug
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: snake-apk
          path: bin/*.apk
```

### 方法三：WSL（Windows Subsystem for Linux）

如果你安装了 WSL：

```bash
# 在 WSL (Ubuntu) 中：
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
pip3 install --user buildozer

# 进入项目目录
cd /path/to/贪吃蛇进化版-android

# 构建
buildozer android debug
```

## 游戏操作

| 操作 | 说明 |
|------|------|
| 👆 滑动 | 控制蛇的移动方向 |
| 📱 点击按钮 | 菜单选择和重新开始 |
| ⌨️ 方向键/WASD | 桌面调试时使用 |
| ESC | 返回菜单 |

## 食物类型

| 食物 | 颜色 | 效果 |
|------|------|------|
| 🟥 普通 | 红色 | 长度+1，分数+1 |
| 🟨 加速 | 黄色 | 长度+1，分数+2，临时加速 |
| 🟦 护盾 | 青色 | 获得护盾，可抵挡一次障碍 |
| 🟪 毒药 | 紫色 | 减速，分数-3 |

## 技术说明

- 游戏核心逻辑位于 `game/core.py`，完全独立于 UI 框架
- Kivy 渲染层位于 `game/screens.py`，通过 Canvas 指令绘制
- 音效运行时自动生成 WAV 文件，无需额外资源
- 最高分保存在应用内部存储中

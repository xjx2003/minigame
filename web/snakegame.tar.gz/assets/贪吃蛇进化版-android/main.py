"""
贪吃蛇进化版 — Android 版 (Kivy)
入口文件
"""
import os
import sys

from kivy.config import Config

# 在导入其他 Kivy 模块之前设置配置
Config.set('kivy', 'window_icon', '')
Config.set('graphics', 'resizable', False)
Config.set('input', 'mouse', 'mouse,disable_multitouch')

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle, Line

from game.core import DIFFICULTY, GameState
from game.screens import GameScreen
from game.sounds import init_sounds, sound_mgr

# 设置窗口大小（桌面调试用）
try:
    from kivy.core.window import Window
    Window.size = (480, 800)   # 手机竖屏比例
except:
    pass


# ==================== 菜单屏幕 ====================
class MenuScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.gs = GameState()  # 仅用于读取最高分
        self._build_ui()

    def _build_ui(self):
        layout = FloatLayout()

        # 背景
        with layout.canvas.before:
            Color(20 / 255, 20 / 255, 35 / 255)
            Rectangle(pos=layout.pos, size=layout.size)
        layout.bind(pos=lambda w, v: self._update_bg(layout),
                    size=lambda w, v: self._update_bg(layout))

        # 标题
        title = Label(
            text='🐍 贪吃蛇\n进化版 🐍',
            font_size=dp(42),
            bold=True,
            color=(1, 200 / 255, 0, 1),
            halign='center',
            valign='middle',
            pos_hint={'center_x': 0.5, 'center_y': 0.82},
        )
        layout.add_widget(title)

        # 难度选择提示
        hint = Label(
            text='选择难度',
            font_size=dp(20),
            color=(0.7, 0.7, 0.8, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.65},
        )
        layout.add_widget(hint)

        # 难度按钮
        self.diff_btns = {}
        diffs = list(DIFFICULTY.keys())
        start_y = 0.55
        for i, d in enumerate(diffs):
            btn = Button(
                text=d,
                font_size=dp(22),
                size_hint=(0.5, 0.07),
                pos_hint={'center_x': 0.5, 'center_y': start_y - i * 0.09},
                background_normal='',
                background_color=(0.25, 0.25, 0.4, 1),
                color=(0.8, 0.8, 1, 1),
            )
            btn.bind(on_press=lambda x, d=d: self._select_difficulty(d))
            layout.add_widget(btn)
            self.diff_btns[d] = btn

        # 最高分显示
        self.hs_label = Label(
            text='',
            font_size=dp(18),
            color=(1, 160 / 255, 50 / 255, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.30},
        )
        layout.add_widget(self.hs_label)

        # 开始按钮
        start_btn = Button(
            text='开始游戏',
            font_size=dp(28),
            bold=True,
            size_hint=(0.7, 0.08),
            pos_hint={'center_x': 0.5, 'center_y': 0.20},
            background_normal='',
            background_color=(0.15, 0.55, 0.15, 1),
            color=(1, 1, 1, 1),
        )
        start_btn.bind(on_press=lambda x: self._start_game())
        layout.add_widget(start_btn)

        # 版本/提示
        ver = Label(
            text='v2.0 · 滑动控制方向',
            font_size=dp(14),
            color=(0.5, 0.5, 0.6, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.05},
        )
        layout.add_widget(ver)

        self.add_widget(layout)
        self._selected_diff = '普通'
        self._update_highlight()

    def _update_bg(self, layout):
        layout.canvas.before.clear()
        with layout.canvas.before:
            Color(20 / 255, 20 / 255, 35 / 255)
            Rectangle(pos=layout.pos, size=layout.size)

    def _select_difficulty(self, diff):
        self._selected_diff = diff
        self._update_highlight()
        sound_mgr.play('menu_move')

    def _update_highlight(self):
        diffs = list(DIFFICULTY.keys())
        for d in diffs:
            btn = self.diff_btns[d]
            if d == self._selected_diff:
                btn.background_color = (0.3, 0.5, 0.7, 1)
                btn.color = (1, 1, 1, 1)
            else:
                btn.background_color = (0.25, 0.25, 0.4, 1)
                btn.color = (0.8, 0.8, 1, 1)
        # 更新最高分
        hs = self.gs.high_scores.get(self._selected_diff, 0)
        self.hs_label.text = f'🏆 最高分: {hs}'

    def _start_game(self):
        game_screen = self.manager.get_screen('game')
        game_screen.gs.difficulty = self._selected_diff
        game_screen.gs.scores_file = game_screen.gs.scores_file  # 保留
        game_screen._restart_game()
        self.manager.current = 'game'

    def on_enter(self):
        """每次进入菜单时刷新最高分"""
        self.gs.load_scores()
        self._update_highlight()


# ==================== App ====================
class SnakeApp(App):
    def build(self):
        # 初始化音效
        try:
            init_sounds()
        except Exception as e:
            print(f'[音效] 初始化跳过: {e}')

        # 设置标题
        self.title = '贪吃蛇进化版'

        # ScreenManager
        sm = ScreenManager()
        sm.add_widget(MenuScreen(name='menu'))
        sm.add_widget(GameScreen(name='game'))
        sm.current = 'menu'

        # 键盘绑定（桌面调试）
        Window.bind(on_key_down=self._on_key_down)

        return sm

    def _on_key_down(self, window, key, scancode, codepoint, modifiers):
        """桌面键盘控制"""
        game_screen = self.root.get_screen('game')
        if self.root.current == 'game':
            game_screen.on_key_down(key)

        # ESC / 返回键
        if key == 27:  # ESC
            if self.root.current == 'game':
                if not game_screen.gs.game_over:
                    # 简单地返回菜单
                    game_screen.on_leave()
                    self.root.current = 'menu'
            else:
                self.stop()


if __name__ == '__main__':
    SnakeApp().run()

[app]

# (str) Title of your application
title = 贪吃蛇进化版

# (str) Package name
package.name = snakeevolution

# (str) Package domain (needed for android/ios packaging)
package.domain = org.snakegame

# (str) Source code where the main.py lives
source.dir = .

# (list) Source files to exclude
source.exclude_exts = spec,pyc,pyo

# (list) List of additions to the default source exclusions
source.exclude_dirs = tests, bin, .git, __pycache__

# (list) List of extra files/directories to include
source.include_exts = py,png,jpg,jpeg,gif,wav,ogg,ttf

# (str) Application versioning
version = 1.0.0

# (str) Application versioning (method 2)
# version.regex = __version__ = ['"](.*)['"]
# version.filename = %(source.dir)s/main.py

# (list) Requirements (libraries to install)
requirements = python3, kivy

# (str) Custom source requirements in requirements.txt format
# e.g., git+https://github.com/kivy/kivy
# requirements.source = requirements.txt

# (str) Presplash of the application
# presplash.filename = %(source.dir)s/images/presplash.png

# (str) Icon of the application
# icon.filename = %(source.dir)s/images/icon.png

# (str) Supported orientation (one of landscape, sensorLandscape, portrait or all)
orientation = portrait

# (list) List of services to declare
# services = NAME:ENTRYPOINT_TO_PY, NAME2:ENTRYPOINT_TO_PY

#
# OSX Specific
#

#
# iOS Specific
#

# (str) Name of the certificate to use for signing
# ios.codesign.allowed = false

# (str) Path to the provisioning profile
# ios.provisioning_profile = Auto

# (str) Path to the codesigning certificate
# ios.codesign.certificate = Auto

#
# Android specific
#

# (bool) Indicate if the application should be fullscreen or not
android.fullscreen = 1

# (string) Presplash background color (in hex)
android.presplash_color = #141423

# (string) The theme used by the splash screen
android.splash_screen_theme = "@android:style/Theme.NoTitleBar"

# (list) Permissions (Android only)
android.permissions = INTERNET

# (int) Android API version to use
android.api = 31

# (int) Minimum API required
android.minapi = 21

# (int) Android SDK version to use
android.sdk = 31

# (str) Android NDK version to use
android.ndk = 25b

# (bool) Use Android's deprecated private storage
android.private_storage = False

# (str) Android NDK directory (if empty, it will be automatically downloaded)
# android.ndk_path =

# (str) Android SDK directory (if empty, it will be automatically downloaded)
# android.sdk_path =

# (str) Ant executive (if empty, it will be automatically downloaded)
# android.ant_path =

# (bool) If True, then skip trying to update the Android SDK
android.accept_sdk_license = True

# (str) Android entry point, default is 'org.kivy.android.PythonActivity'
# android.entrypoint = org.kivy.android.PythonActivity

# (list) A list of Java files to add to the android project
# android.add_src =

# (list) A list of Java files to add to the android project
# android.add_src =

# (list) Additional jars to add to the project
# android.add_jars =

# (list) List of Android AIDL files to compile
# android.add_aidl =

# (str) Python for Android branch
# android.p4a_branch = master

# (str) Python for Android git repository
# android.p4a_dir =

# (list) Android architectures to build for
android.archs = arm64-v8a

# (str) GStreamer support (Android only)
# android.gstreamer = 1.18.5

#
# Windows specific
#

# (list) Windows architectures to build for (one or more of: win32, win_arm64, x64)
# windows.architectures = x64

# (str) Windows packaging toolkit to use (one of: portable, msix)
# windows.packaging_toolkit = portable

#
# macOS specific
#

# (list) macOS architectures to build for (one or more of: x86_64, arm64)
# macos.architectures = arm64

# (list) List of permissions
# macos.permissions = []

#
# Linux specific
#

# (list) Linux architectures to build for (one or more of: x86_64, aarch64)
# linux.architectures = x86_64

#
# Gradle
#

# (bool) If True, then the gradle we use will be downloaded by buildozer, not
# from the SDK.
# gradle.download = False

# (str) The gradle version to use
# gradle.version = 7.6.3

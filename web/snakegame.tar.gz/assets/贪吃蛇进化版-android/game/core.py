"""
贪吃蛇进化版 — 纯游戏逻辑（无 UI 依赖）
可被 Kivy / Pygame / 控制台等任意前端复用
"""
import random
import math
import json
import os
from collections import deque

# ------------------- 常量 -------------------
GRID = 25
COLS, ROWS = 30, 22  # 适用于手机竖屏显示

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

DIFFICULTY = {
    '简单': {'interval': 140, 'obstacles': 0, 'special_food_chance': 0.30},
    '普通': {'interval': 110, 'obstacles': 8, 'special_food_chance': 0.25},
    '困难': {'interval': 80,  'obstacles': 18, 'special_food_chance': 0.20},
}

# ------------------- 粒子系统 -------------------
class Particle:
    def __init__(self, x, y, color, speed_range=(2, 6), life=30):
        self.x = x
        self.y = y
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(*speed_range)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.color = color          # (r, g, b)
        self.life = life
        self.max_life = life
        self.size = random.randint(2, 5)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        return self.life > 0

# ------------------- 蛇 -------------------
class Snake:
    def __init__(self):
        self.reset()

    def reset(self):
        self.body = deque([(COLS // 2, ROWS // 2)])
        self.direction = RIGHT
        self.next_direction = RIGHT
        self.grow_count = 0
        self.speed_multiplier = 1.0
        self.shield = False

    def head(self):
        return self.body[0]

    def change_direction(self, new_dir):
        if (new_dir[0] * -1, new_dir[1] * -1) == self.direction:
            return
        self.next_direction = new_dir

    def move(self, obstacles=None):
        if obstacles is None:
            obstacles = []
        self.direction = self.next_direction
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)

        # 边界
        if new_head[0] < 0 or new_head[0] >= COLS or new_head[1] < 0 or new_head[1] >= ROWS:
            return False

        # 自碰
        if new_head in self.body:
            return False

        # 障碍
        if new_head in obstacles:
            if self.shield:
                self.shield = False
            else:
                return False

        self.body.appendleft(new_head)
        if self.grow_count > 0:
            self.grow_count -= 1
        else:
            self.body.pop()
        return True

    def grow(self, n=1):
        self.grow_count += n

# ------------------- 食物 -------------------
class Food:
    def __init__(self, snake_body, obstacles=None):
        if obstacles is None:
            obstacles = []
        self.type = 'normal'
        self.position = self._random_position(snake_body, obstacles)
        self.spawn_time = 0  # 由 Game 设置

    def _random_position(self, snake_body, obstacles):
        while True:
            pos = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
            if pos not in snake_body and pos not in obstacles:
                return pos


class SpecialFood(Food):
    def __init__(self, snake_body, obstacles, food_type):
        super().__init__(snake_body, obstacles)
        self.type = food_type
        self.position = self._random_position(snake_body, obstacles)


# ------------------- 游戏状态（核心逻辑） -------------------
class GameState:
    """游戏核心状态机，不依赖任何渲染框架"""

    def __init__(self):
        self.scores_file = None  # 由前端设置路径
        self.high_scores = {'简单': 0, '普通': 0, '困难': 0}
        self.load_scores()

        self.difficulty = '普通'
        self.reset_game()

        # 回调钩子（由前端注册）
        self.on_eat = None
        self.on_power = None
        self.on_death = None
        self.on_menu_move = None

        # 特殊食物计时
        self._special_cooldown = 0

    def load_scores(self):
        if self.scores_file and os.path.exists(self.scores_file):
            try:
                with open(self.scores_file, 'r') as f:
                    self.high_scores = json.load(f)
            except:
                pass

    def save_scores(self):
        if self.scores_file:
            try:
                with open(self.scores_file, 'w') as f:
                    json.dump(self.high_scores, f)
            except:
                pass

    def reset_game(self):
        self.snake = Snake()
        self.obstacles = []
        self.foods = []
        self.particles = []
        self.score = 0
        self.game_over = False
        self.diff_settings = DIFFICULTY[self.difficulty]
        self.move_interval = self.diff_settings['interval']

        # 障碍物
        self.obstacles = []
        for _ in range(self.diff_settings['obstacles']):
            for _ in range(100):
                pos = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
                if pos not in self.snake.body and pos != (COLS // 2, ROWS // 2) and pos not in self.obstacles:
                    self.obstacles.append(pos)
                    break

        # 食物
        self.foods.append(Food(self.snake.body, self.obstacles))
        self._special_cooldown = 0

    def spawn_special_food(self):
        if random.random() < self.diff_settings['special_food_chance']:
            types = ['speed', 'shield', 'poison']
            chosen = random.choice(types)
            new_food = SpecialFood(self.snake.body, self.obstacles, chosen)
            if new_food.position not in [f.position for f in self.foods]:
                self.foods.append(new_food)

    def add_particles(self, x, y, color, count=10):
        for _ in range(count):
            self.particles.append(Particle(x, y, color, speed_range=(2, 7), life=20))

    def tick(self, current_time):
        """每帧调用，返回是否继续运行"""
        # 移动蛇
        alive = self.snake.move(self.obstacles)
        if not alive:
            self.game_over = True
            if self.on_death:
                self.on_death()
            # 更新最高分
            if self.score > self.high_scores.get(self.difficulty, 0):
                self.high_scores[self.difficulty] = self.score
                self.save_scores()
            return False

        head = self.snake.head()

        # 吃食物检测
        for food in self.foods[:]:
            if head == food.position:
                fx, fy = food.position[0] * GRID + GRID // 2, food.position[1] * GRID + GRID // 2

                if food.type == 'normal':
                    self.snake.grow(1)
                    self.score += 1
                    if self.on_eat:
                        self.on_eat()
                    self.add_particles(fx, fy, (255, 80, 80), 12)

                elif food.type == 'speed':
                    self.snake.grow(1)
                    self.score += 2
                    self.snake.speed_multiplier = 0.7
                    if self.on_power:
                        self.on_power()
                    self.add_particles(fx, fy, (255, 220, 80), 15)

                elif food.type == 'shield':
                    self.snake.grow(1)
                    self.snake.shield = True
                    if self.on_power:
                        self.on_power()
                    self.add_particles(fx, fy, (0, 230, 230), 20)

                elif food.type == 'poison':
                    self.snake.speed_multiplier = 1.5
                    self.score = max(0, self.score - 3)
                    self.snake.grow(1)
                    if self.on_death:
                        self.on_death()
                    self.add_particles(fx, fy, (200, 100, 255), 10)

                self.foods.remove(food)
                # 保证至少有一个普通食物
                if not any(f.type == 'normal' for f in self.foods):
                    self.foods.append(Food(self.snake.body, self.obstacles))
                break

        # 生成特殊食物
        if current_time - self._special_cooldown > 4000:
            self._special_cooldown = current_time
            self.spawn_special_food()

        # 移除超时特殊食物 (8 秒)
        for food in self.foods[:]:
            if food.type != 'normal' and current_time - food.spawn_time > 8000:
                self.foods.remove(food)

        # 更新粒子
        self.particles = [p for p in self.particles if p.update()]

        return True

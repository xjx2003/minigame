"""
音效模块 — 使用 Kivy SoundLoader
在 Android 上通过加载预置的 OGG/WAV 音效文件工作
如果音效文件不存在，则静默跳过（游戏仍能正常运行）
"""
import os
from kivy.core.audio import SoundLoader

SOUND_DIR = os.path.join(os.path.dirname(__file__), '..', 'sounds')


class SoundManager:
    """统一管理音效，文件不存在时不播放（不崩溃）"""

    def __init__(self):
        self.sounds = {}
        self._ensure_sound_dir()

    def _ensure_sound_dir(self):
        if not os.path.exists(SOUND_DIR):
            try:
                os.makedirs(SOUND_DIR)
            except:
                pass

    def _load(self, name, filename):
        path = os.path.join(SOUND_DIR, filename)
        if os.path.exists(path):
            s = SoundLoader.load(path)
            if s:
                self.sounds[name] = s

    def play(self, name):
        if name in self.sounds:
            s = self.sounds[name]
            s.seek(0)   # 从头播放
            s.play()

    @staticmethod
    def generate_sound_files():
        """生成简单的 WAV 音效文件（纯 Python，无需额外库）"""
        import struct
        import math

        def _save_wav(path, freq, duration_ms, volume=0.3):
            """生成简单方波 WAV 文件"""
            sample_rate = 22050
            num_samples = int(sample_rate * duration_ms / 1000)
            data = []
            for i in range(num_samples):
                t = i / sample_rate
                val = volume if (int(t * freq * 2) % 2 == 0) else -volume
                data.append(val)

            # 转换为 16-bit PCM
            max_amp = 32767 * 0.8
            samples = [int(d * max_amp) for d in data]

            with open(path, 'wb') as f:
                # RIFF header
                f.write(b'RIFF')
                data_size = num_samples * 2  # 16-bit mono
                f.write(struct.pack('<I', 36 + data_size))
                f.write(b'WAVE')
                # fmt chunk
                f.write(b'fmt ')
                f.write(struct.pack('<I', 16))          # chunk size
                f.write(struct.pack('<H', 1))            # PCM
                f.write(struct.pack('<H', 1))            # mono
                f.write(struct.pack('<I', sample_rate))  # sample rate
                f.write(struct.pack('<I', sample_rate * 2))  # byte rate
                f.write(struct.pack('<H', 2))            # block align
                f.write(struct.pack('<H', 16))           # bits per sample
                # data chunk
                f.write(b'data')
                f.write(struct.pack('<I', data_size))
                for s in samples:
                    f.write(struct.pack('<h', s))

        snd_dir = SOUND_DIR
        if not os.path.exists(snd_dir):
            os.makedirs(snd_dir)

        _save_wav(os.path.join(snd_dir, 'eat.wav'), 600, 50, 0.3)
        _save_wav(os.path.join(snd_dir, 'power.wav'), 800, 80, 0.4)
        _save_wav(os.path.join(snd_dir, 'death.wav'), 200, 300, 0.5)
        _save_wav(os.path.join(snd_dir, 'menu_move.wav'), 400, 30, 0.2)
        print(f"[音效] 已生成音效文件到: {snd_dir}")


# 全局单例
sound_mgr = SoundManager()


def init_sounds():
    """初始化音效管理器，加载音效文件"""
    SoundManager.generate_sound_files()
    sound_mgr._load('eat', 'eat.wav')
    sound_mgr._load('power', 'power.wav')
    sound_mgr._load('death', 'death.wav')
    sound_mgr._load('menu_move', 'menu_move.wav')

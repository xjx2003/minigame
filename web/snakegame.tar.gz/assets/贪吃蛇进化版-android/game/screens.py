"""
Kivy 界面 — 负责游戏渲染和用户交互
"""
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivy.graphics import (
    Color, Rectangle, Ellipse, Line, PushMatrix, PopMatrix, Translate
)
from kivy.core.text import Label as CoreLabel
from kivy.metrics import dp
from kivy.utils import get_color_from_hex

from .core import (
    GameState, DIFFICULTY, GRID, COLS, ROWS,
    UP, DOWN, LEFT, RIGHT,
)


# ---------- 颜色 ----------
BLACK = (10 / 255, 10 / 255, 20 / 255)
DARK_BG = (20 / 255, 20 / 255, 35 / 255)
WHITE = (240 / 255, 240 / 255, 255 / 255)
GRAY = (80 / 255, 80 / 255, 100 / 255)
LIGHT_GRAY = (140 / 255, 140 / 255, 160 / 255)
GREEN = (100 / 255, 255 / 255, 100 / 255)
DARK_GREEN = (30 / 255, 150 / 255, 30 / 255)
RED = (255 / 255, 80 / 255, 80 / 255)
YELLOW = (255 / 255, 220 / 255, 80 / 255)
GOLD = (255 / 255, 200 / 255, 0 / 255)
CYAN = (0 / 255, 230 / 255, 230 / 255)
PURPLE = (200 / 255, 100 / 255, 255 / 255)
ORANGE = (255 / 255, 160 / 255, 50 / 255)
GRID_COLOR = (30 / 255, 30 / 255, 45 / 255)


# ---------- 工具函数 ----------
def _text_rect(label, text, font_size=16, bold=False,
               color=(1, 1, 1, 1), halign='center', valign='middle'):
    """创建渲染好的文字 Texture，返回 (texture, w, h)"""
    lbl = CoreLabel(
        text=text,
        font_size=font_size,
        bold=bold,
        color=color,
        halign=halign,
        valign=valign,
    )
    lbl.refresh()
    return lbl.texture, lbl.texture.size[0], lbl.texture.size[1]


# ==================== 游戏画布 ====================
class GameCanvas(Widget):
    """负责绘制游戏主画面（蛇、食物、障碍、粒子）"""

    def __init__(self, game_state, **kwargs):
        super().__init__(**kwargs)
        self.gs = game_state
        self._scale = 1.0
        self._offset_x = 0
        self._offset_y = 0

    def on_size(self, *args):
        """自适应缩放"""
        self.calculate_layout()

    def calculate_layout(self):
        """计算网格缩放，保证完整显示在屏幕内"""
        cell_w = self.width / COLS
        cell_h = self.height / ROWS
        self._scale = min(cell_w, cell_h)
        # 居中偏移
        self._offset_x = (self.width - COLS * self._scale) / 2
        self._offset_y = (self.height - ROWS * self._scale) / 2

    def to_grid(self, x, y):
        """屏幕坐标 → 网格坐标"""
        gx = int((x - self._offset_x) / self._scale)
        gy = int((y - self._offset_y) / self._scale)
        return gx, gy

    def draw(self):
        """重绘画布"""
        self.canvas.clear()
        with self.canvas:
            # 背景
            Color(*BLACK)
            Rectangle(pos=self.pos, size=self.size)

            # 网格
            Color(*GRID_COLOR)
            for x in range(COLS + 1):
                px = self._offset_x + x * self._scale
                Line(points=[px, self._offset_y, px, self._offset_y + ROWS * self._scale],
                     width=0.5)
            for y in range(ROWS + 1):
                py = self._offset_y + y * self._scale
                Line(points=[self._offset_x, py, self._offset_x + COLS * self._scale, py],
                     width=0.5)

            # 障碍物
            Color(*GRAY)
            for ox, oy in self.gs.obstacles:
                x = self._offset_x + ox * self._scale
                y = self._offset_y + oy * self._scale
                Rectangle(pos=(x, y), size=(self._scale, self._scale))

            # 食物
            for food in self.gs.foods:
                self._draw_food(food)

            # 蛇
            self._draw_snake()

            # 粒子
            self._draw_particles()

    def _draw_food(self, food):
        fx, fy = food.position
        cx = self._offset_x + fx * self._scale + self._scale / 2
        cy = self._offset_y + fy * self._scale + self._scale / 2
        r = self._scale * 0.4

        if food.type == 'normal':
            Color(*RED)
            Ellipse(pos=(cx - r, cy - r), size=(r * 2, r * 2))
            # 高光
            Color(1, 1, 1, 0.5)
            Ellipse(pos=(cx - r * 0.4, cy - r * 0.4), size=(r * 0.5, r * 0.5))
        elif food.type == 'speed':
            Color(*YELLOW)
            Ellipse(pos=(cx - r, cy - r), size=(r * 2, r * 2))
            # 闪电符号 ⚡
            Color(0, 0, 0, 0.8)
            self._draw_lightning(cx, cy, r * 0.6)
        elif food.type == 'shield':
            Color(*CYAN)
            Ellipse(pos=(cx - r, cy - r), size=(r * 2, r * 2))
            # 护盾环
            Color(0, 0, 0, 0.6)
            Line(circle=(cx, cy, r - 2), width=2)
        elif food.type == 'poison':
            Color(*PURPLE)
            Ellipse(pos=(cx - r, cy - r), size=(r * 2, r * 2))
            # 骷髅标记
            Color(0, 0, 0, 0.7)
            Ellipse(pos=(cx - r * 0.3, cy + r * 0.1), size=(r * 0.6, r * 0.6))

    def _draw_lightning(self, cx, cy, size):
        """画闪电符号"""
        h = size * 2
        points = [
            cx - size * 0.3, cy + h * 0.4,
            cx + size * 0.1, cy,
            cx - size * 0.05, cy - h * 0.1,
            cx + size * 0.3, cy - h * 0.4,
        ]
        Line(points=points, width=2)

    def _draw_snake(self):
        body = self.gs.snake.body
        direction = self.gs.snake.direction
        length = len(body)
        shield = self.gs.snake.shield

        for i, (gx, gy) in enumerate(body):
            x = self._offset_x + gx * self._scale
            y = self._offset_y + gy * self._scale
            pad = 1
            rect = (x + pad, y + pad, self._scale - pad * 2, self._scale - pad * 2)

            if i == 0:
                # 蛇头
                if shield:
                    Color(*YELLOW)
                else:
                    Color(1, 200 / 255, 50 / 255)
                Rectangle(pos=(x + pad, y + pad), size=(self._scale - pad * 2, self._scale - pad * 2))
                # 眼睛
                eye_r = self._scale * 0.12
                Color(1, 1, 1)
                dx, dy = direction
                cx = x + self._scale / 2
                cy = y + self._scale / 2
                offset = self._scale * 0.25
                if dx == 1:    # right
                    e1 = (cx + offset * 0.6, cy - offset)
                    e2 = (cx + offset * 0.6, cy + offset)
                elif dx == -1:  # left
                    e1 = (cx - offset * 0.6, cy - offset)
                    e2 = (cx - offset * 0.6, cy + offset)
                elif dy == -1:  # up
                    e1 = (cx - offset, cy - offset * 0.6)
                    e2 = (cx + offset, cy - offset * 0.6)
                else:           # down
                    e1 = (cx - offset, cy + offset * 0.6)
                    e2 = (cx + offset, cy + offset * 0.6)
                Ellipse(pos=(e1[0] - eye_r, e1[1] - eye_r), size=(eye_r * 2, eye_r * 2))
                Ellipse(pos=(e2[0] - eye_r, e2[1] - eye_r), size=(eye_r * 2, eye_r * 2))
                # 瞳孔
                Color(0, 0, 0)
                Ellipse(pos=(e1[0] - eye_r / 2, e1[1] - eye_r / 2), size=(eye_r, eye_r))
                Ellipse(pos=(e2[0] - eye_r / 2, e2[1] - eye_r / 2), size=(eye_r, eye_r))
            else:
                # 蛇身渐变色
                t = i / max(length - 1, 1)
                r = 30 / 255 + 70 / 255 * t
                g = 150 / 255 + 100 / 255 * t
                b = 30 / 255 + 50 / 255 * t
                Color(r, g, b)
                Rectangle(pos=(x + pad, y + pad), size=(self._scale - pad * 2, self._scale - pad * 2))

    def _draw_particles(self):
        for p in self.gs.particles:
            alpha = p.life / p.max_life
            cr, cg, cb = p.color
            Color(cr / 255, cg / 255, cb / 255, alpha)
            r = p.size
            pos = (p.x * self._scale / GRID + self._offset_x - r,
                   p.y * self._scale / GRID + self._offset_y - r)
            Ellipse(pos=pos, size=(r * 2, r * 2))


# ==================== 主游戏屏幕 ====================
class GameScreen(Screen):
    """游戏主屏幕 — 包含 GameCanvas + HUD"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.gs = GameState()
        self._move_timer = 0
        self._last_tick = 0
        self._game_clock = None
        self._draw_clock = None

        # 构建 UI
        self.canvas_widget = GameCanvas(self.gs)
        self.add_widget(self.canvas_widget)

        # HUD 标签 - 用 FloatLayout 更好，但这里简单叠加
        from kivy.uix.label import Label
        from kivy.uix.floatlayout import FloatLayout

        self.hud = FloatLayout()
        self.score_label = Label(
            text='分数: 0',
            font_size=dp(18),
            bold=True,
            color=(1, 1, 1, 1),
            size_hint=(None, None),
            pos_hint={'x': 0.02, 'top': 0.98},
            halign='left',
            valign='top',
        )
        self.score_label.texture_size[0] = 1  # 自动
        self.shield_label = Label(
            text='',
            font_size=dp(16),
            bold=True,
            color=CYAN,
            size_hint=(None, None),
            pos_hint={'right': 0.98, 'top': 0.98},
            halign='right',
            valign='top',
        )
        self.hud.add_widget(self.score_label)
        self.hud.add_widget(self.shield_label)
        self.add_widget(self.hud)

        # 游戏结束覆盖层 - 由 show_game_over / hide_game_over 控制
        self._go_widgets = []

        # 触摸方向
        self._touch_start = None

    def on_enter(self):
        """进入屏幕时启动游戏循环"""
        self.gs.reset_game()
        self._last_tick = 0
        self._move_timer = 0
        self.hide_game_over()
        self._game_clock = Clock.schedule_interval(self._update, 1.0 / 60.0)
        self._draw_clock = Clock.schedule_interval(self._redraw, 1.0 / 30.0)

    def on_leave(self):
        """离开屏幕时停止循环"""
        if self._game_clock:
            self._game_clock.cancel()
            self._game_clock = None
        if self._draw_clock:
            self._draw_clock.cancel()
            self._draw_clock = None

    def _update(self, dt):
        """物理更新"""
        current_time = Clock.get_time() * 1000  # ms

        if self.gs.game_over:
            return

        self._move_timer += dt * 1000
        effective_interval = self.gs.move_interval * self.gs.snake.speed_multiplier

        if self._move_timer >= effective_interval:
            self._move_timer -= effective_interval
            self.gs.tick(current_time)
            if self.gs.game_over:
                self.show_game_over()

        # 更新 HUD
        self.score_label.text = f'分数: {self.gs.score}'
        if self.gs.snake.shield:
            self.shield_label.text = '🛡️ 护盾激活'
        else:
            self.shield_label.text = ''

    def _redraw(self, dt):
        """渲染更新（降低频率以节省性能）"""
        self.canvas_widget.draw()

    # ---------- 触摸控制 ----------
    def on_touch_down(self, touch):
        if self.gs.game_over:
            return
        self._touch_start = (touch.x, touch.y)
        return True

    def on_touch_up(self, touch):
        if self.gs.game_over:
            return
        if self._touch_start is None:
            return
        dx = touch.x - self._touch_start[0]
        dy = touch.y - self._touch_start[1]
        self._touch_start = None

        # 滑动手势阈值
        threshold = dp(30)
        if abs(dx) < threshold and abs(dy) < threshold:
            return

        if abs(dx) > abs(dy):
            self.gs.snake.change_direction(RIGHT if dx > 0 else LEFT)
        else:
            self.gs.snake.change_direction(DOWN if dy > 0 else UP)

    # ---------- 键盘控制 (桌面调试) ----------
    def on_key_down(self, key):
        from kivy.core.window import Keyboard
        if key == Keyboard.keycodes['up'] or key == Keyboard.keycodes['w']:
            self.gs.snake.change_direction(UP)
        elif key == Keyboard.keycodes['down'] or key == Keyboard.keycodes['s']:
            self.gs.snake.change_direction(DOWN)
        elif key == Keyboard.keycodes['left'] or key == Keyboard.keycodes['a']:
            self.gs.snake.change_direction(LEFT)
        elif key == Keyboard.keycodes['right'] or key == Keyboard.keycodes['d']:
            self.gs.snake.change_direction(RIGHT)

    # ---------- 游戏结束 ----------
    def show_game_over(self):
        from kivy.uix.floatlayout import FloatLayout
        from kivy.uix.label import Label
        from kivy.uix.button import Button

        overlay = FloatLayout()
        self.add_widget(overlay)
        self._go_widgets.append(overlay)

        # 半透明黑底
        from kivy.graphics import Color, Rectangle
        with overlay.canvas:
            Color(0, 0, 0, 0.75)
            Rectangle(pos=overlay.pos, size=overlay.size)

        overlay.bind(pos=lambda w, v: self._redraw_overlay(overlay),
                     size=lambda w, v: self._redraw_overlay(overlay))

        title = Label(
            text='游戏结束',
            font_size=dp(48),
            bold=True,
            color=(1, 0.3, 0.3, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.65},
        )
        overlay.add_widget(title)

        score_text = f'得分: {self.gs.score}'
        is_new = self.gs.score >= self.gs.high_scores.get(self.gs.difficulty, 0) and self.gs.score > 0
        if is_new:
            score_text += '  🎉 新纪录！'

        score_lbl = Label(
            text=score_text,
            font_size=dp(28),
            color=(1, 1, 1, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.50},
        )
        overlay.add_widget(score_lbl)

        restart_btn = Button(
            text='重新开始',
            font_size=dp(24),
            size_hint=(0.6, 0.08),
            pos_hint={'center_x': 0.5, 'center_y': 0.35},
            background_normal='',
            background_color=(0.2, 0.6, 0.2, 1),
        )
        restart_btn.bind(on_press=lambda x: self._restart_game())
        overlay.add_widget(restart_btn)

        menu_btn = Button(
            text='返回菜单',
            font_size=dp(24),
            size_hint=(0.6, 0.08),
            pos_hint={'center_x': 0.5, 'center_y': 0.25},
            background_normal='',
            background_color=(0.3, 0.3, 0.5, 1),
        )
        menu_btn.bind(on_press=lambda x: self._go_menu())
        overlay.add_widget(menu_btn)

    def _redraw_overlay(self, overlay):
        overlay.canvas.clear()
        with overlay.canvas:
            Color(0, 0, 0, 0.75)
            Rectangle(pos=overlay.pos, size=overlay.size)

    def hide_game_over(self):
        for w in self._go_widgets:
            self.remove_widget(w)
        self._go_widgets.clear()

    def _restart_game(self):
        self.hide_game_over()
        self.gs.reset_game()
        self._move_timer = 0
        self.score_label.text = '分数: 0'
        self.shield_label.text = ''

    def _go_menu(self):
        self.hide_game_over()
        self.manager.current = 'menu'

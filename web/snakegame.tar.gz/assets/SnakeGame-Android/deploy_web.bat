@echo off
REM ============================================
REM 将 Pygbag 构建的 Web 文件复制到 Android 项目
REM ============================================
set "BUILD_DIR=..\build\web"
set "ASSETS_DIR=app\src\main\assets"

echo 正在复制 Web 构建文件到 Android 项目...
if not exist "%BUILD_DIR%" (
    echo [错误] 找不到 Pygbag 构建目录: %BUILD_DIR%
    echo 请先在上级目录运行: pygbag --build pygbag_snake_game.py
    exit /b 1
)

REM 清空旧的 assets
if exist "%ASSETS_DIR%" (
    rmdir /s /q "%ASSETS_DIR%"
)
mkdir "%ASSETS_DIR%"

REM 复制所有文件
xcopy /s /e /y "%BUILD_DIR%\*" "%ASSETS_DIR%\"

echo [完成] Web 文件已复制到 %ASSETS_DIR%
echo 现在可以用 Android Studio 打开本目录并构建 APK
echo 或者运行: ./gradlew assembleDebug

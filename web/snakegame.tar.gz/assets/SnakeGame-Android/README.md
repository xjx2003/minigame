# 🐍 贪吃蛇进化版 — Android (Pygbag + WebView)

这是一个 Android WebView 工程，将 Pygbag 编译的网页版贪吃蛇游戏包装为原生 Android 应用。

## 两种打包方式

### 🅰 方式一：Android Studio（推荐，Windows 可用）

> 需要安装 **Android Studio**（免费，可从 developer.android.com/studio 下载）

**步骤：**

```bash
# 1️⃣ 先在上级目录用 Pygbag 编译游戏为 WebAssembly
cd ..
pygbag --build pygbag_snake_game.py

# 2️⃣ 将 Web 文件复制到 Android 项目
cd SnakeGame-Android
# 双击 deploy_web.bat 或运行:
deploy_web.bat

# 3️⃣ 用 Android Studio 打开 SnakeGame-Android 目录
# 4️⃣ 菜单: Build → Build Bundle(s) / APK → Build APK
# 5️⃣ 生成的 APK 在: app/build/outputs/apk/debug/app-debug.apk
```

或者用命令行（需要安装 Android SDK）：
```bash
# 配置 ANDROID_HOME 环境变量指向你的 Android SDK 路径
set ANDROID_HOME=C:\Users\你的用户名\AppData\Local\Android\Sdk
# 然后
deploy_web.bat
gradlew assembleDebug
```

### 🅱 方式二：PWA Builder（最简单，无需任何 IDE）

> 不需要 Android Studio，不需要写代码，只需一个浏览器

**步骤：**

```bash
# 1️⃣ 用 Pygbag 编译
cd ..
pygbag --build pygbag_snake_game.py
```

**2️⃣ 将 build/web 文件夹上传到任意静态托管服务：**
| 服务 | 说明 | 链接 |
|------|------|------|
| GitHub Pages | 免费，需 GitHub 账号 | github.com |
| Netlify | 免费，拖拽上传 | netlify.com |
| Vercel | 免费 | vercel.com |

**3️⃣ 打开 PWA Builder 网站：**
- 访问 https://pwabuilder.com/
- 输入你部署的网址
- 点击 "Test my PWA"
- 如果通过测试，点击 "Package for Android"
- 下载生成的 APK 即可安装到手机

### 🅲 方式三：部署为 PWA（渐进式网页应用）

直接把 `build/web` 文件夹部署到服务器，用户用 Chrome 访问即可安装到手机桌面。

```bash
# 例如用 Python 内置服务器测试
cd build\web
python -m http.server 8000
# 浏览器访问 http://localhost:8000
# 手机上同一网络访问 http://你的IP:8000
```

## 关于音效的说明

Pygbag 在 WebAssembly 环境中使用 `pygame.mixer` 可能需要用户点击页面后才能激活音频。游戏启动后点击/触摸一下屏幕即可。

## 文件结构

```
SnakeGame-Android/
├── app/
│   ├── src/main/
│   │   ├── assets/         ← 运行时复制 Pygbag 的 build/web 到此处
│   │   ├── java/.../MainActivity.kt  ← WebView 包装代码
│   │   ├── res/            ← 资源文件
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
├── deploy_web.bat          ← 一键复制 Web 文件到 assets
└── build_apk.bat           ← 一键构建 APK
```

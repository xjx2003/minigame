@echo off
REM ============================================
REM 一键构建 APK（需要在 Android Studio 环境中）
REM ============================================
echo [1/3] 复制 Web 构建文件...
call deploy_web.bat
if %errorlevel% neq 0 exit /b %errorlevel%

echo [2/3] 检查 Gradle...
if not exist "gradlew.bat" (
    echo [提示] 没有 gradlew，请用 Android Studio 打开本目录
    echo 或在命令行中运行: gradle wrapper
    pause
    exit /b 0
)

echo [3/3] 开始构建 APK...
call gradlew assembleDebug

echo.
echo ============================================
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo [成功] APK 已生成:
    echo app\build\outputs\apk\debug\app-debug.apk
) else (
    echo [失败] 构建失败，请检查错误信息
)
echo ============================================
pause

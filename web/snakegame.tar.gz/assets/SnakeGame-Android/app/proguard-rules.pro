# 保留 WebView 相关类
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

package com.snakegame.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)

        // WebView 配置
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.setSupportMultipleWindows(true)
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = false

        // 硬件加速
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)

        // 全屏支持
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback) {
                // 处理全屏视频等
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // 页面加载完成后发送点击事件以激活音频
                webView.evaluateJavascript(
                    "document.querySelector('canvas')?.click();", null
                )
            }
        }

        // 加载 Pygbag 生成的网页
        // 方式 1: 从本地 assets 加载（需要先将 build/web 复制到 assets 目录）
        // webView.loadUrl("file:///android_asset/index.html")

        // 方式 2: 从本地 HTTP 服务器加载（推荐，性能更好）
        // 见 LocalServerHelper

        // 方式 3: 从远程 URL 加载（如果已部署到服务器）
        // webView.loadUrl("https://your-domain.com/snake/")

        // 默认使用本地文件
        webView.loadUrl("file:///android_asset/index.html")
    }

    // 返回键处理
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}

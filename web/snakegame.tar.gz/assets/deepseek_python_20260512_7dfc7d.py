import pygame
import random
import sys
import math
import json
import os
import numpy as np
from collections import deque

# ------------------------------
# 初始化
pygame.init()
pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)

# ------------------------------
WINDOW_W, WINDOW_H = 800, 600
GRID = 25
COLS, ROWS = WINDOW_W // GRID, WINDOW_H // GRID
FPS = 60
BASE_MOVE_INTERVAL = 120  # 基础移动间隔(ms)

# 颜色
BLACK = (10, 10, 20)
DARK_BG = (20, 20, 35)
WHITE = (240, 240, 255)
GRAY = (80, 80, 100)
LIGHT_GRAY = (140, 140, 160)
GREEN = (100, 255, 100)
DARK_GREEN = (30, 150, 30)
RED = (255, 80, 80)
YELLOW = (255, 220, 80)
GOLD = (255, 200, 0)
CYAN = (0, 230, 230)
PURPLE = (200, 100, 255)
ORANGE = (255, 160, 50)

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

DIFFICULTY = {
    'Easy':   {'interval': 140, 'obstacles': 0, 'special_food_chance': 0.3},
    'Normal': {'interval': 110, 'obstacles': 8, 'special_food_chance': 0.25},
    'Hard':   {'interval': 80,  'obstacles': 18, 'special_food_chance': 0.2}
}

# ------------------------------
# 音效生成（修复：使用int16数组）
def generate_square_wave(freq, duration_ms, volume=0.3):
    sample_rate = 22050
    num_samples = int(sample_rate * duration_ms / 1000)
    buf = np.zeros((num_samples, 2), dtype=np.int16)
    max_val = int(volume * 32767)
    for i in range(num_samples):
        t = float(i) / sample_rate
        val = max_val if (int(t * freq * 2) % 2 == 0) else -max_val
        buf[i] = [val, val]
    return pygame.sndarray.make_sound(buf)

eat_sound = generate_square_wave(600, 50, 0.3)
power_sound = generate_square_wave(800, 80, 0.4)
death_sound = generate_square_wave(200, 300, 0.5)
menu_move_sound = generate_square_wave(400, 30, 0.2)

# ------------------------------
class Particle:
    def __init__(self, x, y, color, speed_range=(2, 6), life=30):
        self.x = x
        self.y = y
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(*speed_range)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.color = color
        self.life = life
        self.max_life = life
        self.size = random.randint(2, 5)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        return self.life > 0

    def draw(self, surface):
        alpha = int(255 * self.life / self.max_life)
        color = (*self.color, alpha)
        surf = pygame.Surface((self.size * 2, self.size * 2), pygame.SRCALPHA)
        pygame.draw.circle(surf, color, (self.size, self.size), self.size)
        surface.blit(surf, (self.x - self.size, self.y - self.size))

# ------------------------------
SCORE_FILE = "snake_highscores.json"

def load_scores():
    if os.path.exists(SCORE_FILE):
        with open(SCORE_FILE, 'r') as f:
            return json.load(f)
    return {'Easy': 0, 'Normal': 0, 'Hard': 0}

def save_scores(scores):
    with open(SCORE_FILE, 'w') as f:
        json.dump(scores, f)

# ------------------------------
class Snake:
    def __init__(self):
        self.body = deque([(COLS//2, ROWS//2)])
        self.direction = RIGHT
        self.next_direction = RIGHT
        self.grow_count = 0
        self.speed_multiplier = 1.0
        self.shield = False

    def head(self):
        return self.body[0]

    def change_direction(self, new_dir):
        if (new_dir[0] * -1, new_dir[1] * -1) == self.direction:
            return
        self.next_direction = new_dir

    def move(self, obstacles=[]):
        self.direction = self.next_direction
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)

        # 边界检测
        if new_head[0] < 0 or new_head[0] >= COLS or new_head[1] < 0 or new_head[1] >= ROWS:
            return False

        # 自碰
        if new_head in self.body:
            return False

        # 障碍
        if new_head in obstacles:
            if self.shield:
                self.shield = False
            else:
                return False

        self.body.appendleft(new_head)
        if self.grow_count > 0:
            self.grow_count -= 1
        else:
            self.body.pop()
        return True

    def grow(self, n=1):
        self.grow_count += n

    def render(self, surface):
        length = len(self.body)
        for i, (gx, gy) in enumerate(self.body):
            rect = pygame.Rect(gx * GRID, gy * GRID, GRID, GRID)
            if i == 0:
                color = YELLOW if self.shield else (255, 200, 50)
                eye_offset = 6
                eye_size = 5
                if self.direction == UP:
                    eye1 = (gx * GRID + GRID//2 - eye_offset, gy * GRID + GRID//2 - eye_offset)
                    eye2 = (gx * GRID + GRID//2 + eye_offset, gy * GRID + GRID//2 - eye_offset)
                elif self.direction == DOWN:
                    eye1 = (gx * GRID + GRID//2 - eye_offset, gy * GRID + GRID//2 + eye_offset)
                    eye2 = (gx * GRID + GRID//2 + eye_offset, gy * GRID + GRID//2 + eye_offset)
                elif self.direction == LEFT:
                    eye1 = (gx * GRID + GRID//2 - eye_offset, gy * GRID + GRID//2 - eye_offset)
                    eye2 = (gx * GRID + GRID//2 - eye_offset, gy * GRID + GRID//2 + eye_offset)
                else:
                    eye1 = (gx * GRID + GRID//2 + eye_offset, gy * GRID + GRID//2 - eye_offset)
                    eye2 = (gx * GRID + GRID//2 + eye_offset, gy * GRID + GRID//2 + eye_offset)
                pygame.draw.rect(surface, color, rect, border_radius=6)
                pygame.draw.circle(surface, BLACK, eye1, eye_size)
                pygame.draw.circle(surface, BLACK, eye2, eye_size)
            else:
                t = i / max(length-1, 1)
                r = int(30 + 70 * t)
                g = int(150 + 100 * t)
                b = int(30 + 50 * t)
                color = (r, g, b)
                pygame.draw.rect(surface, color, rect, border_radius=5)

class Food:
    def __init__(self, snake_body, obstacles=[]):
        self.type = 'normal'
        self.position = self._random_position(snake_body, obstacles)
        self.spawn_time = pygame.time.get_ticks()

    def _random_position(self, snake_body, obstacles):
        while True:
            pos = (random.randint(0, COLS-1), random.randint(0, ROWS-1))
            if pos not in snake_body and pos not in obstacles:
                return pos

    def render(self, surface):
        x, y = self.position
        cx, cy = x * GRID + GRID//2, y * GRID + GRID//2
        if self.type == 'normal':
            color = RED
            radius = GRID//2 - 2
            pygame.draw.circle(surface, color, (cx, cy), radius)
            pygame.draw.circle(surface, WHITE, (cx-4, cy-4), 3)
        elif self.type == 'speed':
            color = YELLOW
            radius = GRID//2 - 2
            pygame.draw.circle(surface, color, (cx, cy), radius)
            pygame.draw.circle(surface, WHITE, (cx-4, cy-4), 3)
        elif self.type == 'shield':
            color = CYAN
            radius = GRID//2 - 2
            pygame.draw.circle(surface, color, (cx, cy), radius)
            pygame.draw.circle(surface, (0,0,0), (cx, cy), radius-3, 2)
        elif self.type == 'poison':
            color = PURPLE
            radius = GRID//2 - 2
            pygame.draw.circle(surface, color, (cx, cy), radius)
            pygame.draw.circle(surface, WHITE, (cx-3, cy-3), 2)

class SpecialFood(Food):
    def __init__(self, snake_body, obstacles, food_type):
        super().__init__(snake_body, obstacles)
        self.type = food_type
        self.position = self._random_position(snake_body, obstacles)

# ------------------------------
class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
        pygame.display.set_caption("✨ 贪吃蛇 进化版 ✨")
        self.clock = pygame.time.Clock()
        self.font_small = pygame.font.SysFont('microsoftyahei', 20, bold=True)
        self.font_medium = pygame.font.SysFont('microsoftyahei', 36, bold=True)
        self.font_large = pygame.font.SysFont('microsoftyahei', 56, bold=True)
        self.state = 'MENU'
        self.difficulty = 'Normal'
        self.high_scores = load_scores()
        self.reset_game()

    def reset_game(self):
        self.snake = Snake()
        self.obstacles = []
        self.foods = []
        self.particles = []
        self.score = 0
        self.move_timer = 0
        self.game_over = False
        self.paused = False
        self.diff_settings = DIFFICULTY[self.difficulty]
        self.move_interval = self.diff_settings['interval']
        # 障碍
        self.obstacles = []
        for _ in range(self.diff_settings['obstacles']):
            while True:
                pos = (random.randint(0, COLS-1), random.randint(0, ROWS-1))
                if pos not in self.snake.body and pos != (COLS//2, ROWS//2):
                    self.obstacles.append(pos)
                    break
        # 食物
        self.foods.append(Food(self.snake.body, self.obstacles))
        self.special_cooldown = pygame.time.get_ticks()

    def spawn_special_food(self):
        if random.random() < self.diff_settings['special_food_chance']:
            types = ['speed', 'shield', 'poison']
            chosen = random.choice(types)
            new_food = SpecialFood(self.snake.body, self.obstacles, chosen)
            if new_food.position not in [f.position for f in self.foods]:
                self.foods.append(new_food)

    def add_particles(self, x, y, color, count=10):
        for _ in range(count):
            self.particles.append(Particle(x, y, color, speed_range=(2, 7), life=20))

    # ---------- 事件处理（统一管理，包括USER定时器） ----------
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            # 用户事件：速度恢复 / 毒药恢复
            if event.type == pygame.USEREVENT + 1:
                self.snake.speed_multiplier = 1.0
            if event.type == pygame.USEREVENT + 2:
                self.snake.speed_multiplier = 1.0

            if event.type == pygame.KEYDOWN:
                if self.state == 'MENU':
                    self._menu_key(event.key)
                elif self.state == 'PLAYING':
                    self._playing_key(event.key)
                elif self.state == 'PAUSED':
                    self._paused_key(event.key)
                elif self.state == 'GAME_OVER':
                    self._gameover_key(event.key)
        return True

    def _menu_key(self, key):
        if key == pygame.K_UP or key == pygame.K_w:
            menu_move_sound.play()
            diffs = list(DIFFICULTY.keys())
            idx = diffs.index(self.difficulty)
            idx = (idx - 1) % len(diffs)
            self.difficulty = diffs[idx]
        elif key == pygame.K_DOWN or key == pygame.K_s:
            menu_move_sound.play()
            diffs = list(DIFFICULTY.keys())
            idx = diffs.index(self.difficulty)
            idx = (idx + 1) % len(diffs)
            self.difficulty = diffs[idx]
        elif key == pygame.K_RETURN or key == pygame.K_SPACE:
            self.state = 'PLAYING'
            self.reset_game()
        elif key == pygame.K_ESCAPE:
            pygame.quit()
            sys.exit()

    def _playing_key(self, key):
        if key == pygame.K_UP or key == pygame.K_w:
            self.snake.change_direction(UP)
        elif key == pygame.K_DOWN or key == pygame.K_s:
            self.snake.change_direction(DOWN)
        elif key == pygame.K_LEFT or key == pygame.K_a:
            self.snake.change_direction(LEFT)
        elif key == pygame.K_RIGHT or key == pygame.K_d:
            self.snake.change_direction(RIGHT)
        elif key == pygame.K_p or key == pygame.K_ESCAPE:
            self.state = 'PAUSED'

    def _paused_key(self, key):
        if key == pygame.K_p or key == pygame.K_ESCAPE:
            self.state = 'PLAYING'
        elif key == pygame.K_q:
            self.state = 'MENU'

    def _gameover_key(self, key):
        if key == pygame.K_r:
            self.reset_game()
            self.state = 'PLAYING'
        elif key == pygame.K_m or key == pygame.K_ESCAPE:
            self.state = 'MENU'

    # ---------- 游戏更新 ----------
    def update_playing(self, dt):
        self.move_timer += dt
        effective_interval = self.move_interval * self.snake.speed_multiplier
        if self.move_timer >= effective_interval:
            self.move_timer -= effective_interval
            alive = self.snake.move(self.obstacles)
            if not alive:
                self.state = 'GAME_OVER'
                death_sound.play()
                if self.score > self.high_scores.get(self.difficulty, 0):
                    self.high_scores[self.difficulty] = self.score
                    save_scores(self.high_scores)
                return

            head = self.snake.head()
            for food in self.foods[:]:
                if head == food.position:
                    fx, fy = head[0]*GRID+GRID//2, head[1]*GRID+GRID//2
                    if food.type == 'normal':
                        self.snake.grow(1)
                        self.score += 1
                        eat_sound.play()
                        self.add_particles(fx, fy, RED, 12)
                    elif food.type == 'speed':
                        self.snake.grow(1)
                        self.score += 2
                        self.snake.speed_multiplier = 0.7
                        power_sound.play()
                        self.add_particles(fx, fy, YELLOW, 15)
                        pygame.time.set_timer(pygame.USEREVENT+1, 5000, True)
                    elif food.type == 'shield':
                        self.snake.grow(1)
                        self.snake.shield = True
                        power_sound.play()
                        self.add_particles(fx, fy, CYAN, 20)
                    elif food.type == 'poison':
                        self.snake.speed_multiplier = 1.5
                        self.score = max(0, self.score - 3)
                        self.snake.grow(1)
                        death_sound.play()
                        self.add_particles(fx, fy, PURPLE, 10)
                        pygame.time.set_timer(pygame.USEREVENT+2, 5000, True)
                    self.foods.remove(food)
                    # 确保普通食物存在
                    if not any(f.type == 'normal' for f in self.foods):
                        self.foods.append(Food(self.snake.body, self.obstacles))
                    break

            # 特殊食物生成
            now = pygame.time.get_ticks()
            if now - self.special_cooldown > 4000:
                self.special_cooldown = now
                self.spawn_special_food()

            # 移除超时特殊食物
            for food in self.foods[:]:
                if food.type != 'normal' and now - food.spawn_time > 8000:
                    self.foods.remove(food)

        # 粒子更新
        self.particles = [p for p in self.particles if p.update()]

    # ---------- 绘图 ----------
    def draw_menu(self):
        self.screen.fill(DARK_BG)
        title = self.font_large.render("🐍 贪吃蛇 进化版 🐍", True, GOLD)
        title_rect = title.get_rect(center=(WINDOW_W//2, 150))
        self.screen.blit(title, title_rect)

        diff_text = self.font_medium.render("选择难度 (↑↓)", True, WHITE)
        diff_rect = diff_text.get_rect(center=(WINDOW_W//2, 260))
        self.screen.blit(diff_text, diff_rect)

        diffs = list(DIFFICULTY.keys())
        for i, d in enumerate(diffs):
            color = CYAN if d == self.difficulty else LIGHT_GRAY
            txt = self.font_medium.render(d, True, color)
            rect = txt.get_rect(center=(WINDOW_W//2, 320 + i * 50))
            self.screen.blit(txt, rect)

        hs = self.high_scores[self.difficulty]
        hs_text = self.font_small.render(f"最高分: {hs}", True, ORANGE)
        hs_rect = hs_text.get_rect(center=(WINDOW_W//2, 480))
        self.screen.blit(hs_text, hs_rect)

        start_text = self.font_small.render("按 Enter 或 Space 开始", True, WHITE)
        start_rect = start_text.get_rect(center=(WINDOW_W//2, 530))
        self.screen.blit(start_text, start_rect)

    def draw_game(self):
        self.screen.fill(BLACK)
        # 网格
        for x in range(0, WINDOW_W, GRID):
            pygame.draw.line(self.screen, (30, 30, 45), (x, 0), (x, WINDOW_H))
        for y in range(0, WINDOW_H, GRID):
            pygame.draw.line(self.screen, (30, 30, 45), (0, y), (WINDOW_W, y))

        # 障碍
        for ox, oy in self.obstacles:
            rect = pygame.Rect(ox * GRID, oy * GRID, GRID, GRID)
            pygame.draw.rect(self.screen, (100, 100, 120), rect, border_radius=5)
            pygame.draw.rect(self.screen, (60, 60, 80), rect.inflate(-6, -6), border_radius=3)

        # 食物
        for food in self.foods:
            food.render(self.screen)

        # 蛇
        self.snake.render(self.screen)

        # 粒子
        for p in self.particles:
            p.draw(self.screen)

        # HUD
        score_text = self.font_small.render(f"分数: {self.score}", True, WHITE)
        self.screen.blit(score_text, (10, 10))
        if self.snake.shield:
            shield_text = self.font_small.render("🛡️ 护盾激活", True, CYAN)
            self.screen.blit(shield_text, (WINDOW_W - 180, 10))

    def draw_pause(self):
        overlay = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        pause_text = self.font_large.render("暂停", True, WHITE)
        pause_rect = pause_text.get_rect(center=(WINDOW_W//2, WINDOW_H//2 - 30))
        self.screen.blit(pause_text, pause_rect)
        hint = self.font_small.render("按 P 继续 | 按 Q 返回菜单", True, LIGHT_GRAY)
        hint_rect = hint.get_rect(center=(WINDOW_W//2, WINDOW_H//2 + 30))
        self.screen.blit(hint, hint_rect)

    def draw_game_over(self):
        overlay = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 200))
        self.screen.blit(overlay, (0, 0))
        go_text = self.font_large.render("游戏结束", True, RED)
        go_rect = go_text.get_rect(center=(WINDOW_W//2, 180))
        self.screen.blit(go_text, go_rect)
        score_text = self.font_medium.render(f"分数: {self.score}", True, WHITE)
        score_rect = score_text.get_rect(center=(WINDOW_W//2, 260))
        self.screen.blit(score_text, score_rect)
        if self.score > self.high_scores.get(self.difficulty, 0):
            new_text = self.font_small.render("🎉 新纪录！", True, GOLD)
            new_rect = new_text.get_rect(center=(WINDOW_W//2, 310))
            self.screen.blit(new_text, new_rect)
        restart_text = self.font_small.render("按 R 重新开始 | 按 M 返回菜单", True, LIGHT_GRAY)
        restart_rect = restart_text.get_rect(center=(WINDOW_W//2, 400))
        self.screen.blit(restart_text, restart_rect)

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS)
            running = self.handle_events()

            if self.state == 'PLAYING':
                self.update_playing(dt)
                self.draw_game()
            elif self.state == 'MENU':
                self.draw_menu()
            elif self.state == 'PAUSED':
                self.draw_game()
                self.draw_pause()
            elif self.state == 'GAME_OVER':
                self.draw_game()
                self.draw_game_over()

            pygame.display.flip()

        pygame.quit()
        sys.exit()

# ------------------------------
if __name__ == "__main__":
    game = Game()
    game.run()